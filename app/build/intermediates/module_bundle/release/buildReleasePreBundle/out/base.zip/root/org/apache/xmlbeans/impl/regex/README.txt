This is an isolated directory that was taken from the
Apache Xerces-J 2.0 project.

BMPPattern.java,v 1.4 2004/02/24
Match.java,v 1.5 2004/02/24
Op.java,v 1.4 2004/02/24
ParseException.java,v 1.4 2004/02/24
ParserForXMLSchema.java,v 1.6 2004/02/24
RangeToken.java,v 1.5 2004/02/24
RegexParser.java,v 1.9 2004/02/24
RegularExpression.java,v 1.8 2004/02/24
REUtil.java,v 1.8 2004/02/24
Token.java,v 1.8 2004/02/24
message.properties, 1.6 2003/03/25

It contains the following modifications:

(1) a change in namespace.
(2) the addition of a SchemaRegularExpression class for fast
    detection of NCNAME, etc.
(3) Bugfix in file ParserForXMLSchema:237

No xbean code outside this directory or other directories with
similar README notices was taken from Apache.
